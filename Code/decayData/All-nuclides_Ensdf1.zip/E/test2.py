# -*- coding: utf-8 -*-
"""
Created on Tue May 16 15:38:47 2023

@author: lenovo
"""
import zipfile
import numpy as np
z = 'D:\学习安排\M2\资料\E\\At-218.txt'

with open (z) as f:
    data = f.readlines()
    nl = np.size(data)
    for i in range(nl):
        data[i] = str(data[i])
        data[i] = data[i].replace("b'",'')
        data[i] = data[i].replace("\\r\\n'",'')
    for i in range(nl):
        data[i] = data[i].split()
    for i in range(nl):
        if i>0 and ("L" in data[i]) and ("AUGER" in data[i]) and ("|]" in data[i-1]):
            data.insert(i,[data[i][0],'T'])
            
    index_auger = []
    daugther = []
    index_end = []
    posi = [] 
    #按空白线和P的位置定位
    for i,p in enumerate(data):
        if 'DECAY' in p:
            daugther.append(p[0])
        if 'Auger' in p:
            index_auger.append(i)
            #posi.append(i)
        if len(p)==2 and 'T' in p:
            posi.append(i)
        if 'P' in p:
            index_end.append(i)
            posi.append(i)
    #对posi进一步处理，去除空白空白第一项/第二项 以及切除某一项中无有用值的行
    posi_del = []
    for i,p in enumerate(posi):
        DATA = data[p]
        if 'XK' in DATA:
            if len(DATA)==4 and '|]' not in DATA:
                posi_del.append(p)
            elif '|]' in DATA and len(DATA)==5:
    '''
    #for i,p in enumerate()
    energy = []
    Energy = []
    prob = []
    Prob = []
    Type = []
    type_ = []
    for i in range(len(posi)-1):
        start = posi[i]+1
        end = posi[i+1]
        d = data[start:end]
        e = []
        prob_b = []
        type_b = []
        if start == end:
            continue
        if start-1 in index_end:
            continue
        #print(d)
        #print("  ")
        #print(start,end)
        for n,p1 in enumerate(d):
            if '-' in p1[2]:
                x = p1[2].split('-')
                p1[2] = round((float(x[1])+float(x[0]))/2,3)
            if '(total)' in d[0]:
                if '(total)' in p1:
                    prob_b.append(float(p1[3]))
                    e.append(p1[2])
                    type_b.append(p1[-2])
                continue    
                #print(p1[2])
            elif '|]' in p1:
                if len(p1)>6:              #----- repèrer la proba
                    prob_b.append(float(p1[4]))
                e.append(float(p1[2]))
                if 'AUGER' in p1:          #----- repèrer le type de transition Auger
                    if 'K' in p1[-2]:
                        type_b.append('Auger K')
                    else:
                        print('erreur')
                elif 'X' in p1[-1]:
                    type_b.append(p1[-1][0:3])
            else:
                if len(p1)==4 and 'X' in p1[-1]:
                    continue
                elif len(p1)==5 and 'L' in p1:
                    continue
                else:
                    e.append(float(p1[2]))
                    prob_b.append(float(p1[3]))
                    if 'L' in p1[-2]:
                        type_b.append('Auger L')
                    #print('Auger L')
                    else:
                        type_b.append(p1[-1][0:3])
        #print(prob_b,e,type_b)
        #print(" ")
        if len(prob_b)==1 and len(e)>1:
            energy.append(np.mean(e))
            prob.append(prob_b[0])
            type_.append(type_b[0])
        elif len(e)==len(prob_b):
            for i in range(len(e)):
                energy.append(e[i])
                prob.append(prob_b[i])
                type_.append(type_b[i])
        #print(energy)
        #print(end)
        if end in index_end or end+1 in index_end:
            print('size')
            print(len(energy),len(prob),len(type_))
            Energy.append(energy)
            Prob.append(prob)
            Type.append(type_)
            energy = []
            prob = []
            type_ = []
    '''