# -*- coding: utf-8 -*-
"""
Created on Tue May 16 11:08:31 2023

@author: lenovo
"""

import zipfile
import numpy as np

file = 'All-nuclides_Ensdf.zip'
z = zipfile.ZipFile(file)

with z.open('Am-241.txt') as f:
    data = f.readlines()
    nl = np.size(data)
    for i in range(nl):
        data[i] = str(data[i])
        data[i] = data[i].replace("b'",'')
        data[i] = data[i].replace("\\r\\n'",'')
    for i in range(nl):
        data[i] = data[i].split()
    for i in range(nl):
        if i>0 and ("L" in data[i]) and ("AUGER" in data[i]) and ("|]" in data[i-1]):
            data.insert(i,[data[i][0],'T'])
    d = data[22:25]
    if '(total)' in d:
        print('ok')
    for i,p in enumerate(d):
        if float(p[4])