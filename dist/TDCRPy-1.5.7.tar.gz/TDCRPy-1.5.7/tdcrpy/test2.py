# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 14:49:40 2023

@author: jialin.hu
"""

#import TDCR_model_lib as tl
#import numpy as np
import tdcrpy.TDCRPy as td
#L = (1, 1, 1)
L = 1
TD = 0.977667386529166
TAB = 0.992232838598821
TBC = 0.992343419459002
TAC = 0.99275350064608
Rad="Cd-109"
pmf_1="1"
N = 10
kB =1.0e-5
V = 10
mode = "eff"
mode2 = "sym"

out = td.TDCRPy(L, TD, TAB, TBC, TAC, Rad, pmf_1, N, kB, V, mode, mode2, Display=True, barp=False,uncData=False)  

