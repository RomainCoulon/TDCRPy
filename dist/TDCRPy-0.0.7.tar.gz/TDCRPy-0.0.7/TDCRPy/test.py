# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 19:15:23 2023

@author: romain.coulon
"""
import TDCRPy

TDCRPy.TDCRPy(1, 0.5, 0.5, 0.5, 0.5, "H-3", "1", 10, 0.00001, 1,10, "eff", "sym", Display=True)


TDCRPy.TDCRPy(L, TD, TAB, TBC, TAC, Rad, pmf_1, N, kB, RHO, nE, mode, mode2)